class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_16.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_17.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.___torch_mangle_18.ReLU
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_19.Conv2d
  __annotations__["4"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_20.BatchNorm2d
  __annotations__["5"] = __torch__.torch.nn.modules.activation.___torch_mangle_21.ReLU
  __annotations__["6"] = __torch__.torch.nn.modules.conv.___torch_mangle_22.Conv2d
  __annotations__["7"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_23.BatchNorm2d
  __annotations__["8"] = __torch__.torch.nn.modules.activation.___torch_mangle_24.ReLU
  __annotations__["9"] = __torch__.torch.nn.modules.conv.___torch_mangle_25.Conv2d
  __annotations__["10"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_26.BatchNorm2d
  __annotations__["11"] = __torch__.torch.nn.modules.activation.___torch_mangle_27.ReLU
  __annotations__["12"] = __torch__.torch.nn.modules.conv.___torch_mangle_28.Conv2d
  __annotations__["13"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_29.BatchNorm2d
  __annotations__["14"] = __torch__.torch.nn.modules.activation.___torch_mangle_30.ReLU
  __annotations__["15"] = __torch__.torch.nn.modules.conv.___torch_mangle_31.Conv2d
  __annotations__["16"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_32.BatchNorm2d
  __annotations__["17"] = __torch__.torch.nn.modules.activation.___torch_mangle_33.ReLU
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_34.Sequential,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "17")
    _1 = getattr(self, "16")
    _2 = getattr(self, "15")
    _3 = getattr(self, "14")
    _4 = getattr(self, "13")
    _5 = getattr(self, "12")
    _6 = getattr(self, "11")
    _7 = getattr(self, "10")
    _8 = getattr(self, "9")
    _9 = getattr(self, "8")
    _10 = getattr(self, "7")
    _11 = getattr(self, "6")
    _12 = getattr(self, "5")
    _13 = getattr(self, "4")
    _14 = getattr(self, "3")
    _15 = getattr(self, "2")
    _16 = getattr(self, "1")
    _17 = (getattr(self, "0")).forward(argument_1, )
    _18 = (_15).forward((_16).forward(_17, ), )
    _19 = (_13).forward((_14).forward(_18, ), )
    _20 = (_11).forward((_12).forward(_19, ), )
    _21 = (_9).forward((_10).forward(_20, ), )
    _22 = (_6).forward((_7).forward((_8).forward(_21, ), ), )
    _23 = (_3).forward((_4).forward((_5).forward(_22, ), ), )
    _24 = (_0).forward((_1).forward((_2).forward(_23, ), ), )
    return _24
