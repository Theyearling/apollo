class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_55.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_56.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.___torch_mangle_57.ReLU
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_58.Conv2d
  __annotations__["4"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_59.BatchNorm2d
  __annotations__["5"] = __torch__.torch.nn.modules.activation.___torch_mangle_60.ReLU
  __annotations__["6"] = __torch__.torch.nn.modules.conv.___torch_mangle_61.Conv2d
  __annotations__["7"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_62.BatchNorm2d
  __annotations__["8"] = __torch__.torch.nn.modules.activation.Sigmoid
