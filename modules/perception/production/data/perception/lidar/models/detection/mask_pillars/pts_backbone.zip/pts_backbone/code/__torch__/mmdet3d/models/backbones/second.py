class SECOND(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  blocks : __torch__.torch.nn.modules.container.___torch_mangle_54.ModuleList
  softmasks : __torch__.torch.nn.modules.container.___torch_mangle_84.ModuleList
  def forward(self: __torch__.mmdet3d.models.backbones.second.SECOND,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = getattr(self.blocks, "2")
    _1 = getattr(self.softmasks, "2")
    _2 = getattr(self.blocks, "1")
    _3 = getattr(self.softmasks, "1")
    _4 = (getattr(self.blocks, "0")).forward(input, )
    _5 = (_3).forward(_4, )
    _6 = (_2).forward(_4, )
    input0 = torch.add(torch.mul(_6, _5), _6, alpha=1)
    _7 = (_1).forward(input0, )
    _8 = (_0).forward(input0, )
    _9 = torch.add(torch.mul(_8, _7), _8, alpha=1)
    return (_4, input0, _9)
